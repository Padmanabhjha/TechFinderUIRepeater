﻿(function () {

    //jquery stuff
    $(document).ready(function () {

       // alert('Inside document ready in home controller');
        //if ($("#newInsRadio").prop("checked")) {
        //    // do something
        //    $('#typeSection').css("display", "block");
        //    $('#mainTypeSection').css("display", "none");

        //}

        //if ($("#mainRadio").prop("checked")) {
        //    $('#typeSection').css("display", "none");
        //    // do something

        //}

        //$("#radioGroup input[name='serviceType']").click(function () {

        //    if ($('input:radio[name=serviceType]:checked').val() == "new_install") {
        //        $('#typeSection').css("display", "block");
        //        $('#mainTypeSection').css("display", "none");
        //        $('#map').css("display", "none");
        //        $('#booking').css("display", "none");
        //    } else {
        //        $('#mainTypeSection').css("display", "block");
        //        $('#typeSection').css("display", "none");
        //        $('#map').css("display", "none");
        //        $('#booking').css("display", "none");
        //    }
        });

        //$("#typeSection").change(function () {
        //       $('#map').css("display", "block");
        //       $('#booking').css("display", "block");
        //       initialize_map();
        //  });
        //$("#mainTypeSection").change(function () {
        //      $('#map').css("display", "block");
        //      $('#booking').css("display", "block");
        //      initialize_map();
        // });

    //};


    //angular stuff
    var app = angular.module("myapp");

    var homeController = function ($scope, $http) {

        $scope.InstallationFlag = true;
        $scope.serviceType = "install";

        function initialize_map(location) {
            var bounds = new google.maps.LatLngBounds();

            //var locations = [['Technician', 17.49, 78.38, 4],
            //    ['You', 17.431, 78.4469, 5]];

            var locations = location;
            //console.log(locations);

            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 10,
                center: new google.maps.LatLng(17.50, 78.45),
                mapTypeId: google.maps.MapTypeId.ROADMAP
            });

            var infowindow = new google.maps.InfoWindow();

            var marker, i;

            for (i = 0; i < locations.length; i++) {
                marker = new google.maps.Marker(
                    {
                        position: new google.maps.LatLng(locations[i][1],
                            locations[i][2]),
                        map: map
                    });
                bounds.extend(marker.position);

                google.maps.event.addListener(marker, 'click', (function (marker, i) {
                    return function () {
                        infowindow.setContent(locations[i][0]);
                        infowindow.open(map, marker);
                    }
                })(marker, i));
                if (i == 0) {
                    console.log($scope.ETA);
                    infowindow.setContent($scope.ETA + " minutes");
                    infowindow.open(map, marker);
                }

            };
            //var infowindow = new google.maps.InfoWindow({
            //    content:$scope.ETA+ " minutes"
            //});

            //infowindow.open(map,marker2);
        

            map.fitBounds(bounds);
        }
        
        $scope.message = "This is home view"
        var onsuccess = function (data) {
            alert('Inside success');
            alert(data);
            $scope.data = data;
            //important to parse
            var jsonObject = JSON.parse(data);
            alert(jsonObject);
            alert(jsonObject[0].Id);
            alert(data[0])
            $scope.id = jsonObject[0].Name;
        };

        var onError = function () {
            $scope.error = "something went wronge";

        };
        function showPosition(position) {
            //x.innerHTML = "Latitude: " + position.coords.latitude +
            //"<br>Longitude: " + position.coords.longitude;
            //alert('inside show position');
            //console.log(position.coords);
            $scope.position = position.coords;
        }
        $scope.init = function () {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                alert( "Geolocation is not supported by this browser.");
            }
        };

        function deg2rad(deg) {
            return deg * (Math.PI / 180)
        }

        function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad(lat2 - lat1);  // deg2rad below
            var dLon = deg2rad(lon2 - lon1);
            var a =
              Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2)
            ;
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
            return d;
        }

        var selectNearestTechnician = function (technicianObj) {
            $scope.avgSpeed = 15;
            var d = 0;
            var min = 0;
            var obj = {
                Technicians: technicianObj
            };
            for (var i = 0; i < obj.Technicians.length; i++) {
                d = getDistanceFromLatLonInKm($scope.position.latitude, $scope.position.longitude, obj.Technicians[i].Latitute, obj.Technicians[i].Longitute);
                if (d < getDistanceFromLatLonInKm($scope.position.latitude, $scope.position.longitude, obj.Technicians[min].Latitute, obj.Technicians[min].Longitute))
                    min = i;
            }
            var minDist = getDistanceFromLatLonInKm($scope.position.latitude, $scope.position.longitude, obj.Technicians[min].Latitute, obj.Technicians[min].Longitute);
            console.log(minDist);
            console.log('mindistance');
           $scope.ETA = minDist / $scope.avgSpeed * 60;
           $scope.ETA = Math.round($scope.ETA);
           return obj.Technicians[min];

        };

        $scope.getTechnician = function (InstallationType) {

            //alert(InstallationType);
            $http.get('http://localhost:60796/api/Technician?lat=' + $scope.position.latitude + '&longitude=' + $scope.position.longitude + '&skill=' + InstallationType).then(function (response) {
                //console.log(response);
                //console.log(response.data);
                //console.log(JSON.parse(response.data));
                var responseobject = JSON.parse(response.data).Table[0];
                console.log(JSON.parse(response.data).Table);
                var technicianObj = JSON.parse(response.data).Table;
                var min = selectNearestTechnician(technicianObj);
                //console.log(JSON.parse(response.data).Table[0].Longitute);
                //.log(JSON.parse(response.data).Table[0].Latitute);
                //console.log(response.data.Table[0].Longitute);
                //console.log($scope.position);
                var locations = [['Technician', min.Latitute, min.Longitute, 4],
              ['You', $scope.position.latitude, $scope.position.longitude, 5]];
                //alert(response);
                initialize_map(locations);

            });
        };

        $scope.showrightdiv = function (flag) {
            alert('inside show grid');
            if (flag == 1)
                $scope.InstallationFlag = true;
            else if(flag==2)
                $scope.InstallationFlag = false;
        };
       
        //extractService.getData().then(onsuccess,onError);
        
   };
    

    app.controller("homeController", ["$scope","$http", homeController]);

}());